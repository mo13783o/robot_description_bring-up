/*
 * ESP32 Robot Controller
 * Communicates with ROS 2 via Serial
 * - Receives: 'L,R' speed commands
 * - Sends: 'enc1,enc2,ax,ay,az,gx,gy,gz' sensor data
 */

#include <Wire.h>

// IMU (MPU6050 example - adjust for your sensor)
#define MPU6050_ADDR 0x68
#define ACCEL_XOUT_H 0x3B
#define GYRO_XOUT_H 0x43

// Motor pins (adjust to your motor driver)
#define MOTOR_LEFT_PWM 25
#define MOTOR_LEFT_DIR 26
#define MOTOR_RIGHT_PWM 27
#define MOTOR_RIGHT_DIR 14

// Encoder pins (adjust to your encoders)
#define ENCODER_LEFT_A 32
#define ENCODER_LEFT_B 33
#define ENCODER_RIGHT_A 34
#define ENCODER_RIGHT_B 35

// Volatile encoder counts
volatile long encoder_left = 0;
volatile long encoder_right = 0;

// Timing
unsigned long last_publish = 0;
const unsigned long PUBLISH_INTERVAL = 50; // 20 Hz

// IMU calibration offsets (calibrate your sensor!)
float accel_offset_x = 0, accel_offset_y = 0, accel_offset_z = 0;
float gyro_offset_x = 0, gyro_offset_y = 0, gyro_offset_z = 0;

void setup() {
  Serial.begin(115200);
  
  // Motor setup
  pinMode(MOTOR_LEFT_PWM, OUTPUT);
  pinMode(MOTOR_LEFT_DIR, OUTPUT);
  pinMode(MOTOR_RIGHT_PWM, OUTPUT);
  pinMode(MOTOR_RIGHT_DIR, OUTPUT);
  
  // Encoder setup
  pinMode(ENCODER_LEFT_A, INPUT_PULLUP);
  pinMode(ENCODER_LEFT_B, INPUT_PULLUP);
  pinMode(ENCODER_RIGHT_A, INPUT_PULLUP);
  pinMode(ENCODER_RIGHT_B, INPUT_PULLUP);
  
  attachInterrupt(digitalPinToInterrupt(ENCODER_LEFT_A), encoderLeftISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_RIGHT_A), encoderRightISR, CHANGE);
  
  // I2C for IMU
  Wire.begin();
  
  // Initialize MPU6050
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x6B); // PWR_MGMT_1 register
  Wire.write(0);    // Wake up MPU6050
  Wire.endTransmission(true);
  
  delay(100);
  
  Serial.println("ESP32 Ready");
}

void loop() {
  // Read incoming commands from ROS 2
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    parseCommand(command);
  }
  
  // Publish sensor data at fixed rate
  unsigned long now = millis();
  if (now - last_publish >= PUBLISH_INTERVAL) {
    publishSensorData();
    last_publish = now;
  }
}

void parseCommand(String cmd) {
  // Expected format: "L,R\n"
  int commaIndex = cmd.indexOf(',');
  
  if (commaIndex > 0) {
    int speedLeft = cmd.substring(0, commaIndex).toInt();
    int speedRight = cmd.substring(commaIndex + 1).toInt();
    
    setMotorSpeed(speedLeft, speedRight);
  }
}

void setMotorSpeed(int left, int right) {
  // Left motor
  if (left >= 0) {
    digitalWrite(MOTOR_LEFT_DIR, HIGH);
    analogWrite(MOTOR_LEFT_PWM, constrain(left, 0, 255));
  } else {
    digitalWrite(MOTOR_LEFT_DIR, LOW);
    analogWrite(MOTOR_LEFT_PWM, constrain(-left, 0, 255));
  }
  
  // Right motor
  if (right >= 0) {
    digitalWrite(MOTOR_RIGHT_DIR, HIGH);
    analogWrite(MOTOR_RIGHT_PWM, constrain(right, 0, 255));
  } else {
    digitalWrite(MOTOR_RIGHT_DIR, LOW);
    analogWrite(MOTOR_RIGHT_PWM, constrain(-right, 0, 255));
  }
}

void publishSensorData() {
  // Read encoders
  noInterrupts();
  long enc1 = encoder_left;
  long enc2 = encoder_right;
  interrupts();
  
  // Read IMU
  float ax, ay, az, gx, gy, gz;
  readIMU(ax, ay, az, gx, gy, gz);
  
  // Send data in format: enc1,enc2,ax,ay,az,gx,gy,gz
  Serial.print(enc1);
  Serial.print(",");
  Serial.print(enc2);
  Serial.print(",");
  Serial.print(ax, 3);
  Serial.print(",");
  Serial.print(ay, 3);
  Serial.print(",");
  Serial.print(az, 3);
  Serial.print(",");
  Serial.print(gx, 3);
  Serial.print(",");
  Serial.print(gy, 3);
  Serial.print(",");
  Serial.println(gz, 3);
}

void readIMU(float &ax, float &ay, float &az, float &gx, float &gy, float &gz) {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(ACCEL_XOUT_H);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU6050_ADDR, 14, true);
  
  // Read accelerometer (raw)
  int16_t ax_raw = Wire.read() << 8 | Wire.read();
  int16_t ay_raw = Wire.read() << 8 | Wire.read();
  int16_t az_raw = Wire.read() << 8 | Wire.read();
  
  // Skip temperature
  Wire.read(); Wire.read();
  
  // Read gyroscope (raw)
  int16_t gx_raw = Wire.read() << 8 | Wire.read();
  int16_t gy_raw = Wire.read() << 8 | Wire.read();
  int16_t gz_raw = Wire.read() << 8 | Wire.read();
  
  // Convert to physical units
  // Accel: ±2g range, 16384 LSB/g -> convert to m/s^2
  ax = (ax_raw / 16384.0) * 9.81;
  ay = (ay_raw / 16384.0) * 9.81;
  az = (az_raw / 16384.0) * 9.81;
  
  // Gyro: ±250°/s range, 131 LSB/(°/s) -> convert to rad/s
  gx = (gx_raw / 131.0) * (PI / 180.0);
  gy = (gy_raw / 131.0) * (PI / 180.0);
  gz = (gz_raw / 131.0) * (PI / 180.0);
  
  // Apply calibration offsets (if calibrated)
  ax -= accel_offset_x;
  ay -= accel_offset_y;
  az -= accel_offset_z;
  gx -= gyro_offset_x;
  gy -= gyro_offset_y;
  gz -= gyro_offset_z;
}

// Encoder interrupt service routines
void IRAM_ATTR encoderLeftISR() {
  if (digitalRead(ENCODER_LEFT_A) == digitalRead(ENCODER_LEFT_B)) {
    encoder_left++;
  } else {
    encoder_left--;
  }
}

void IRAM_ATTR encoderRightISR() {
  if (digitalRead(ENCODER_RIGHT_A) == digitalRead(ENCODER_RIGHT_B)) {
    encoder_right++;
  } else {
    encoder_right--;
  }
}
